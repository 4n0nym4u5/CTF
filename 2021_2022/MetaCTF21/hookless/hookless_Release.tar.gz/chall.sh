#!/bin/bash

cd /chall && ./chall
