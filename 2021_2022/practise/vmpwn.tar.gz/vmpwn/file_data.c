#include "file_data.h"

#include <stdlib.h>
#include <malloc.h>
#include <string.h>

// constructor
file_data* file_data_create(){
    // alloc space
    file_data* fd = (file_data*)malloc(sizeof(file_data));
    if(fd == NULL){
        fprintf(stderr, "Failed to create file_data\n");
        return NULL;
    }

    fd->data = NULL;
    fd->size = 0;
    fd->name = NULL;

    return fd;
}

// destructor
void file_data_destroy(file_data* fd){
    // if data is allocated, free that
    if(fd->data){
        free((void*)fd->data);
    }

    // if name is stored then free it
    if(fd->name){
        free((void*)fd->name);
    }

    // free file data itself
    if(fd){
        free((void*)fd);
    }

    // safety, idk
    fd = NULL;
}

// read file and store data
file_data* file_data_read(const char* name, size_t* readsz){
    // create file data struct
    file_data* fd = file_data_create();
    if(fd == NULL){
        return NULL;
    }

    // store file name in fd
    fd->name = (char*)malloc(strlen(name));
    if(fd->name == NULL){
        fprintf(stderr, "Failed to allocate %zu bytes of memory", strlen(name));
        return NULL;
    }

    // open file for reading
    FILE* file = fopen(name, "r");
    if(file == NULL){
        fprintf(stderr, "Failed to read file \"%s\"\n", name);
        return NULL;
    }

    // get file size
    fseek(file, 0, SEEK_END);
    fd->size = ftell(file);
    fseek(file, 0, SEEK_SET);

    if(fd->size == 0){
        fprintf(stderr, "File \"%s\" has 0 size\n", name);
        return NULL;
    }

    // allocate new buffer
    fd->data = (uint8_t*)(malloc(fd->size * sizeof(char)));
    if(fd->data == NULL){
        fprintf(stderr, "Failed to allocate %lu bytes of memory\n", fd->size);
        return NULL;
    }

    // read from file
    size_t readsize = fread(fd->data, sizeof(uint8_t), fd->size, file);
    if(readsize < fd->size){
        fprintf(stderr, "Failed to completely read file\n"
                "\tACTUAL SIZE : %zu\n"
                "\tREAD SIZE : %zu\n",
                fd->size, readsize);
        return NULL;
    }

    if(readsz != NULL) *readsz = readsize;

    // close file after reading
    fclose(file);

    return fd;
}

// write data to file
void file_data_write(file_data* fd, const char* name, size_t* writesz){
    // check if file data is valid
    if(fd == NULL){
        fprintf(stderr, "Invalid file data provided\n");
    }

    // check if file data buffer is valid
    if(fd->data == NULL){
        fprintf(stderr, "Invalid buffer in provided file data\n");
    }

    // open file for writing
    FILE* file = fopen(name, "w");
    if(file == NULL){
        fprintf(stderr, "Failed to open file \"%s\"\n", name);
    }

    // write to file
    size_t writesize = fwrite(fd->data, sizeof(uint8_t), fd->size, file);

    if(writesz != NULL) *writesz = writesize;

    // close file
    fclose(file);
}
