#ifndef HEADER_H_
#define HEADER_H_

struct vmctx{
    long long r0;
    long long r1;
    long long r2;
    long long stackptr;
    long long f4;
    long long bcptr;
};

#endif // HEADER_H_
