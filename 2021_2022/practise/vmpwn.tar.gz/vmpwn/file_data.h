// defines file data utility for reading file

#ifndef FILE_DATA_H_
#define FILE_DATA_H_

#include <stddef.h>
#include <stdint.h>

typedef struct{
    uint8_t* data;
    size_t size;
    const char* name;
} file_data;

// constructor
file_data* file_data_create();
// destructor
void file_data_destroy(file_data* fd);
// read file into given file data struct
// readsz is the number of bytes of file read
file_data* file_data_read(const char* name, size_t* readsz);
// write data to file
// writesz is the number of bytes written to file
void file_data_write(file_data* fd, const char* name, size_t* writesz);

#endif // FILE_DATA_H_
