#include "file_data.h"
#include <stdint.h>
#include <stdio.h>
#include <linux/prctl.h>
#include <stdlib.h>
#include <unistd.h>

typedef uint64_t u64;
typedef uint32_t u32;
typedef uint16_t u16;
typedef uint8_t u8;
typedef int64_t i64;
typedef int32_t i32;
typedef int16_t i16;
typedef int8_t  i8;

#define EMULATEONLY 1

typedef struct{
    i64 r0;
    i64 r1;
    i64 r2;
    i64 *stack;
    i64 f4;
    u8 *bc;
} vmctx;

void setup_buffers_and_permissions(){
    setbuf(stdout, 0LL);
    setbuf(stdin, 0LL);
    setbuf(stderr, 0LL);
}

void vmerror(const char *a1){
  printf("vm runtime error:%s\n", a1);
  exit(-1);
}

// prints r12ory like a hexdump
void printmem(u8* mem, size_t len){
    for(u64 i = 0; i < len; i++){
        if((i % 16) == 0) printf("\n0x%3lx : ", i);
        printf("%2x ", mem[i]);
    }

    putchar('\n');
}

int main(){
    i64 v, syscall_id, pc, sp;

    setup_buffers_and_permissions();

    vmctx* vm = (vmctx*)(calloc(0x30uLL, 1uLL));
    u8* heap = (u8 *)calloc(0x1000uLL, 1uLL);
    i64* stack = (i64 *)calloc(0x2000uLL, 1uLL); // 8kb stack
    vm->stack = (i64*)((u64)stack + 0x3C0);

    file_data* fd = file_data_read("vmpwn", NULL);

    u64 bc_addr = 0x203020;
    u64 data_addr = 0x203000;
    u64 data_offset = 0x3000;
    u64 bc_offset = (bc_addr - data_addr) + data_offset;
    vm->bc = fd->data + bc_offset;

    u64 bc_sz = 0x2038df - data_addr;
    u8* bcptr = vm->bc;

    if (!heap || !stack)
        vmerror("out of memory");
    while (1) {
        sp = ((u64)vm->stack - (u64)stack);

#if defined(EMULATEONLY)
        printf("\n\nr0 = 0x%lx | r1 = 0x%lx | r2 = 0x%lx | sp = 0x%lx\n", vm->r0, vm->r1, vm->r2, sp);
#endif
        pc = (u64)(vm->bc - bcptr);

#if defined(EMULATENONLY)
        printf("[ 0x%3lx ] : %2x : ", pc, *vm->bc);
#endif

        switch (*vm->bc++){
        case 0x10:
            vm->r0 = (u64)vm->stack;
#if defined(EMULATEONLY)
            printf("lea r0, sp[0x00] \t; sp = 0x%lx\n", vm->r0);
#endif
            break;
        case 0x11:
            vm->r0 = *(u64*)vm->bc;
#if defined(EMULATEONLY)
            printf("mov r0, imm(0x%lx)\n", vm->r0);
#endif
            vm->bc += 8;
            break;
        case 0x12:
            vm->r1 = *(u64*)vm->bc;
#if defined(EMULATEONLY)
            printf("mov r1, imm(0x%lx)\n", vm->r1);
#endif
            vm->bc += 8;
            break;
        case 0x13:
            vm->r2 = *(u64*)vm->bc;
#if defined(EMULATEONLY)
            printf("mov r2, imm(0x%lx)\n", vm->r2);
#endif
            vm->bc += 8;
            break;
        case 0x20: // fetch mem
            v = *(u64*)vm->bc;
            if (v < 0 || v > 0xFFF)
                vmerror("buffer overflow detected");
            vm->r0 = (u64)&heap[v];
#if defined(EMULATEONLY)
            printf("lea r0, heap[0x%lx]\n", v);
#endif
            vm->bc += 8;
            break;
        case 0x21: // fetch mem
            v = *(u64*)vm->bc;
            if (v < 0 || v > 0xFFF)
                vmerror("buffer overflow detected");
            vm->r0 = *(u64*)&heap[v];
#if defined(EMULATEONLY)
            printf("mov r0, heap[0x%lx] \t; r0 = 0x%lx\n", v, vm->r0);
#endif
            vm->bc += 8;
            break;
        case 0x22:
            v = *(u64*)vm->bc;
            if (v < 0 || v > 0xFFF)
                vmerror("buffer overflow detected");
            vm->r1 = *(u64*)&heap[v];
#if defined(EMULATEONLY)
            printf("mov r1, heap[0x%lx] \t; r1 = 0x%lx\n", v, vm->r1);
#endif
            vm->bc += 8;
            break;
        case 0x23:
            v = *(u64*)vm->bc;
            if (v < 0 || v > 0xFFF)
                vmerror("buffer overflow detected");
            vm->r2 = *(u64*)&heap[v];
#if defined(EMULATEONLY)
            printf("mov r2, heap[0x%lx] \t; r2 = 0x%lx\n", v, vm->r2);
#endif
            vm->bc += 8;
            break;
        case 0x33:
            v = *(u64*)vm->bc;
            if (v < 0 || v > 0xFFF)
                vmerror("buffer overflow detected");
            *(u64*)&heap[v] = vm->r0;
#if defined(EMULATEONLY)
            printf("mov heap[0x%lx], r0 \t; r0 = 0x%lx\n", v, vm->r0);
#endif
            vm->bc += 8;
            break;
        case 0x34:
            v = *(u64*)vm->bc;
            if (v < 0 || v > 0xFFF)
                vmerror("buffer overflow detected");
            *(u64*)&heap[v] = vm->r1;
#if defined(EMULATEONLY)
            printf("mov heap[0x%lx], r1 \t; r1 = 0x%lx\n", v, vm->r1);
#endif
            vm->bc += 8;
            break;
        case 0x35:
            v = *(u64*)vm->bc;
            if (v < 0 || v > 0xFFF)
                vmerror("buffer overflow detected");
            *(u64*)&heap[v] = vm->r2;
#if defined(EMULATEONLY)
            printf("mov heap[0x%lx], r2 \t; r2 = 0x%lx\n", v, vm->r2);
#endif
            vm->bc += 8;
            break;
        case 0x44:
            if ((char *) vm->stack - (char *) stack <= 8)
                vmerror("stack underflow detected");
            *--vm->stack = vm->r0;
#if defined(EMULATEONLY)
            printf("push r0 \t; r0 = 0x%lx\n", vm->r0);
#endif
            break;
        case 0x45:
            if ((char *) vm->stack - (char *) stack <= 8)
                vmerror("stack underflow detected");
            *--vm->stack = vm->r1;
#if defined(EMULATEONLY)
            printf("push r1 \t; r1 = 0x%lx\n", vm->r1);
#endif
            break;
        case 0x46:
            if ((char *) vm->stack - (char *) stack <= 8)
                vmerror("stack underflow detected");
            *--vm->stack = vm->r2;
#if defined(EMULATEONLY)
            printf("push r1 \t; r1 = 0x%lx\n", vm->r1);
#endif
            break;
        case 0x51:
            if ((char *) vm->stack - (char *) stack > 0x1DFF)
                vmerror("stack overflow detected");
            vm->r0 = *vm->stack;
#if defined(EMULATEONLY)
            printf("pop r0 \t; r0 = 0x%lx\n", vm->r0);
#endif
            vm->stack++;
            break;
        case 0x52:
            if ((char *) vm->stack - (char *) stack > 0x1DFF)
                vmerror("stack overflow detected");
            v = (u64)vm->stack;
            vm->r1 = *vm->stack;
#if defined(EMULATEONLY)
            printf("pop r1 \t; r1 = 0x%lx\n", vm->r1);
#endif
            vm->stack++;
            break;
        case 0x53:
            if ((char *) vm->stack - (char *) stack > 0x1DFF)
                vmerror("stack overflow detected");
            vm->r2 = *vm->stack;
#if defined(EMULATEONLY)
            printf("pop r2 \t; r2 = 0x%lx\n", vm->r2);
#endif
            vm->stack++;
            break;
        case 0x61:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("add r0, imm(0x%lx) \t; r0 = 0x%lx -> 0x%lx\n", v, vm->r0, vm->r0 + v);
#endif
            vm->r0 += v;
            break;
        case 0x62:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("add r1, imm(0x%lx) \t; r1 = 0x%lx -> 0x%lx\n", v, vm->r1, vm->r1 + v);
#endif
            vm->r1 += v;
            break;
        case 0x63:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("add r2, imm(0x%lx) \t; r2 = 0x%lx -> 0x%lx\n", v, vm->r2, vm->r2 + v);
#endif
            vm->r2 += v;
            break;
        case 0x64:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("add r0, imm(0x%lx) \t; r0 = 0x%lx -> 0x%lx\n", v, vm->r0, vm->r0 - v);
#endif
            vm->r0 -= v;
            break;
        case 0x65:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("add r1, imm(0x%lx) \t; r1 = 0x%lx -> 0x%lx\n", v, vm->r1, vm->r1 - v);
#endif
            vm->r1 -= v;
            break;
        case 0x66:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("add r2, imm(0x%lx) \t; r2 = 0x%lx -> 0x%lx\n", v, vm->r2, vm->r2 - v);
#endif
            vm->r2 -= v;
            break;
        case 0x67:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("mul r0, imm(0x%lx) \t; r0 = 0x%lx -> 0x%lx\n", v, vm->r0, vm->r0 * v);
#endif
            vm->r0 *= v;
            break;
        case 0x68:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("mul r1, imm(0x%lx) \t; r1 = 0x%lx -> 0x%lx\n", v, vm->r1, vm->r1 * v);
#endif
            vm->r1 *= v;
            break;
        case 0x69:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("mul r2, imm(0x%lx) \t; r2 = 0x%lx -> 0x%lx\n", v, vm->r2, vm->r2 * v);
#endif
            vm->r2 *= v;
            break;
        case 0x6A:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("xor r0, imm(0x%lx) \t; r0 = 0x%lx -> 0x%lx\n", v, vm->r0, vm->r0 ^ v);
#endif
            vm->r0 ^= v;
            break;
        case 0x6B:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("xor r1, imm(0x%lx) \t; r1 = 0x%lx -> 0x%lx\n", v, vm->r1, vm->r1 ^ v);
#endif
            vm->r1 ^= v;
            break;
        case 0x6C:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("xor r2, imm(0x%lx) \t; r2 = 0x%lx -> 0x%lx\n", v, vm->r2, vm->r2 ^ v);
#endif
            vm->r2 ^= v;
            break;
        case 0x6D:
            vm->r0 = 0;
#if defined(EMULATEONLY)
            printf("mov r0, imm(0x00)\n");
#endif
            break;
        case 0x6E:
            vm->r1 = 0;
#if defined(EMULATEONLY)
            printf("mov r1, imm(0x00)\n");
#endif
            break;
        case 0x6F:
            vm->r2 = 0;
#if defined(EMULATEONLY)
            printf("mov r2, imm(0x00)\n");
#endif
            break;
        case 0x7E:
            v = *(int16_t*) vm->bc;
            pc = (u64)(vm->bc - bcptr) + 2 + v;
#if defined(EMULATEONLY)
            printf("njmp addr(0x%lx)\n", pc);
#endif
            vm->bc += 2;
            vm->bc += v;
            break;
        case 0x7F:
            vm->bc = (u8 *)vm->r0;
            pc = (u64)(vm->bc - bcptr);
#if defined(EMULATEONLY)
            printf("fjmp addr(0x%lx)\n", pc);
#endif
            break;
        case 0x80:
            *++vm->stack = (u64)vm->bc;
            vm->bc = (u8*)vm->r0;
            pc = (u64)(vm->bc - bcptr);
#if defined(EMULATEONLY)
            printf("fcall addr(0x%lx)\n", pc);
#endif
            break;
        case 0x81:
            v = *(u64*)vm->bc;
            vm->bc += 8;
            vm->stack += v / 8;
#if defined(EMULATEONLY)
            printf("add sp, imm(0x%lx)\n", v);
#endif
            break;
        case 0x82:
            v = *(u64*) vm->bc;
            vm->bc += 8;
#if defined(EMULATEONLY)
            printf("sub sp, imm(0x%lx) \t sp = 0x%lx -> 0x%lx\n", v, sp, sp - v/8);
#endif
            vm->stack -= v/8;
            break;
        case 0x88:
            v = *(int16_t*) vm->bc;
            vm->bc += 2;
            *++vm->stack = (u64) vm->bc;
            vm->bc += v;
            pc = (u64)(vm->bc - bcptr);
#if defined(EMULATEONLY)
            printf("ncall addr(0x%lx)\n", pc);
#endif
            break;
        case 0x8F: // do a read/write/puts/free syscall
            syscall_id = *vm->bc++;
            if(syscall_id == 0){
#if defined(EMULATEONLY)
                printf("read(0x%lx, 0x%lx, 0x%lx)\n", vm->r0, vm->r1, vm->r2);
#endif
                read(vm->r0, (void*)vm->r1, vm->r2);
            }else if(syscall_id == 1){
#if defined(EMULATEONLY)
                printf("write(0x%lx, 0x%lx, 0x%lx)\n", vm->r0, vm->r1, vm->r2);
#endif
                write(vm->r0, (void*)vm->r1, vm->r2);
            }else if(syscall_id == 2){
#if defined(EMULATEONLY)
                printf("puts(0x%lx)\n", vm->r0);
#endif
                puts((const char*)vm->r0);
            }else{
#if defined(EMULATEONLY)
                printf("free(0x%lx)\n", vm->r0);
#endif
                free((void*)vm->r0);
            }
            break;
        case 0x90:
            v = (u64)vm->stack--;
            vm->bc = (u8*)*((u64*)v);
            pc = (u64)(vm->bc - bcptr);
#if defined(EMULATEONLY)
            printf("ret \t; pc = 0x%lx\n", pc);
#endif
            break;
        case 0xFF:
#if defined(EMULATEONLY)
            printf("leave\n");
#endif
            return 0;
        default:
            printf(":%d\n", *vm->bc);
            vmerror("Illegal Instrumention");
        }
#if defined(EMULATEONLY)
        printmem((u8*)stack, 0x400);
#endif
    }
}
